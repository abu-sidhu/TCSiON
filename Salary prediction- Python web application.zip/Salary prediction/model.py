# Salary prediction model
import pandas as pd
import pickle
#reading dataset
df = pd.read_csv("WA_Fn-UseC_-HR-Employee-Attrition.csv")

# removing unwanted features
df=df.drop(['Attrition','EmployeeCount','EmployeeNumber','Over18'
            ,'StandardHours'],axis=1)
#outlier handling
for i in ['NumCompaniesWorked','TrainingTimesLastYear']:
    q1 = df[i].quantile(0.25) 
    q3 = df[i].quantile(0.75) 
    iqr = q3 - q1 
    upper_limit = q3 + 1.5 * iqr
    lower_limit = q1 - 1.5 * iqr 
#     outlier replacement with upper limit and lower limit instead of removing
    df[i][df[i]>upper_limit] = upper_limit
    df[i][df[i]<lower_limit] = lower_limit

#label encoding
from sklearn.preprocessing import LabelEncoder
label_en=LabelEncoder()
for i in df.columns:
    if df[i].dtype == object:
        df[i]=label_en.fit_transform(df[i])
# Splitting Target and featrues
y = df['MonthlyIncome']
x = df.drop('MonthlyIncome', axis = 1)
#feature reduction
corr=x.corr()
# dropping higly correlated features
x = x.drop(['JobLevel','PerformanceRating','YearsInCurrentRole','YearsWithCurrManager'],axis=1)
#spliting train and test
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(x, y, random_state =123, test_size = .2)
# random forest Regressor
from sklearn.ensemble import RandomForestRegressor
rand_f=RandomForestRegressor()
#Fitting the model
m=rand_f.fit(X_train,y_train)
#Saving the model to disk
pickle.dump(rand_f,open('model.pkl','wb') )